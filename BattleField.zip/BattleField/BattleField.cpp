#include "BattleField.hpp"
#include<iostream>
// #include<windows.h>
void BattleField::drawObjects(){
    // call draw functions of all the objects here
    for(auto& b: bullets){
        b -> draw();
    }
    for (auto& t: tanks){
        t -> draw(); 
    }
}
void BattleField::createObject(int x, int y){
    // let's make a rectangel on x, y of the size 30, 10
    SDL_Rect mov = {x, y, 90, 30};
    Tank* t1 = new Tank(gRenderer, assets, mov);
    tanks.push_back(t1);
    //delete t1;
    std::cout<<"Mouse clicked at: "<<x<<" -- "<<y<<std::endl;
}

BattleField::BattleField(SDL_Renderer *renderer, SDL_Texture *asst):gRenderer(renderer), assets(asst){
}

void BattleField::fire(){
    cout<<"F key is pressed"<<endl;
    // provide code to fire all of the tanks.
    for (auto& t: tanks){
        bullets.push_back(t->fire());
    }
}

void BattleField::deleteObj(){
    for (auto& b: bullets)
        delete b;
    bullets.clear();
    for (auto& t: tanks)
        delete t;
    tanks.clear();
    cout << "delete called" << endl;
}
