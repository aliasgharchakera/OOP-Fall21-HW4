// Inherit from Unit class
#include "Unit.hpp"
#include "Bullet.hpp"

class TankTurret: public Unit{
    SDL_Rect src, mover;
    int forward = 0;
    public:
    TankTurret(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov);

    void TurretForward();
    void draw();
    SDL_Rect position();
    Bullet* fire();
};