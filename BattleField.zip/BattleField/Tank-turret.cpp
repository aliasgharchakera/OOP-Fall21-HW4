#include "Tank-turret.hpp"    

    TankTurret::TankTurret(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov): Unit(rend, ast), mover(mov){
        src = {603, 0, 507, 152};
    }

    void TankTurret::draw(){
        Unit::draw(src, mover);
        if (forward == 1){
            mover.x += 30;
            forward = 0;
        }
        mover.x+=2;
    }

    SDL_Rect TankTurret::position(){
        return mover;
    }

    void TankTurret::TurretForward(){
        mover.x -= 30;
        forward = 1;
    }

    Bullet* TankTurret::fire(){
        SDL_Rect movb = mover;
        movb.x += movb.w; movb.y += 11;
        movb.w = 30; movb.h = 10;
        TurretForward();
        return *{rend, ast, movb};
    }