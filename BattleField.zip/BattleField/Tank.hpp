// Make composition of TankBody and TankTurret objects in Tank class
#include "Tank-body.hpp"
#include "Tank-turret.hpp"

class Tank: public TankBody, public TankTurret{
    public:
    Tank(SDL_Renderer*, SDL_Texture*, SDL_Rect);
    void draw();
    SDL_Rect getTurret();
    void TurretForward();
    Bullet* fire();
};