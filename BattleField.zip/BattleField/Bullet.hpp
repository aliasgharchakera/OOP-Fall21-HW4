#include "Unit.hpp"

class Bullet: public Unit{
    SDL_Rect src, mover;
    int n = 0;
    public:
    Bullet(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov);

    void draw();
    void animation(int);
    SDL_Rect position();
};